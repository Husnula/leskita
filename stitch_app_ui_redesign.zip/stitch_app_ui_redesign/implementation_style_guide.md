# Implementation Guide: LesKita Design to Antigravity IDE

To implement the **Luminous Education System** design into your project, follow these steps:

### 1. Set Up Your Tailwind Configuration
The design uses a custom teal-based palette. Update your `tailwind.config.js` to include the primary brand colors:

```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#14b8a6', // Teal 500
          foreground: '#ffffff',
        },
        surface: {
          DEFAULT: '#f8f9ff',
          container: '#eff4ff',
        },
        // Add other tokens from the Design System artifact
      },
      borderRadius: {
        'eight': '8px',
      }
    }
  }
}
```

### 2. Component Structure
Since you are using **Next.js**, break the layout into reusable shared components as identified in your dashboard:

*   **`LayoutShell.tsx`**: Contains the `SideNavBar` and `TopNavBar`. Wrap your pages in this component for consistency.
*   **`MetricCard.tsx`**: Used for the dashboard stats (Total Institutions, MRR, etc.).
*   **`DataTable.tsx` / `Grid.tsx`**: For managing lists like Tutors/Teachers.

### 3. Applying the Style to New Menus
Whenever you create new pages (e.g., "Payments" or "Classes"):
1.  **Use the Shell**: Ensure they are wrapped in the shared `SideNavBar` component.
2.  **Follow the Spacing**: Use `px-page-margin-desktop` (standardized padding) for all main content areas.
3.  **Typography**: Use the `Hanken Grotesk` font family and standard heading sizes (Headline Small/Medium) defined in the design system.

### 4. Continuous Design
Because I have established the **Luminous Education System** as your project's design system, any new screens you ask me to generate in the future will automatically use these same colors, fonts, and component styles.