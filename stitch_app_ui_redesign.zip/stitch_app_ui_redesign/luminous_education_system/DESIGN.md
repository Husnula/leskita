---
name: Luminous Education System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3c4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6c7a77'
  outline-variant: '#bbcac6'
  surface-tint: '#006b5f'
  primary: '#006b5f'
  on-primary: '#ffffff'
  primary-container: '#14b8a6'
  on-primary-container: '#00423b'
  inverse-primary: '#4fdbc8'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#55615f'
  on-tertiary: '#ffffff'
  tertiary-container: '#9aa7a4'
  on-tertiary-container: '#313d3b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#71f8e4'
  primary-fixed-dim: '#4fdbc8'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005048'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d8e5e2'
  tertiary-fixed-dim: '#bcc9c6'
  on-tertiary-fixed: '#121e1c'
  on-tertiary-fixed-variant: '#3d4947'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  page-margin-desktop: 2rem
  page-margin-mobile: 1rem
  gutter: 1.5rem
  card-padding: 1.5rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

## Brand & Style

The design system is rooted in **Modern Corporate** aesthetics with a strong emphasis on **SaaS Minimalism**. It aims to evoke a sense of organized clarity, professional growth, and administrative ease for tutoring management. The interface prioritizes high-contrast readability and "breathable" layouts to reduce the cognitive load often associated with data-heavy dashboards.

The visual narrative is defined by:
- **Clarity & Precision:** Sharp typography and generous whitespace signal a reliable, high-utility tool.
- **Supportive Accents:** Utilizing a fresh teal/mint palette to provide energetic visual cues without overwhelming the professional atmosphere.
- **Mobile-First Utility:** A hierarchy designed to reflow seamlessly from complex desktop data views to focused mobile management tasks.

## Colors

The palette is built on a "Mint-to-Slate" spectrum. 

- **Primary (Teal/Mint):** Used for primary actions, active navigation states, and brand-identifying accents. It represents growth and vitality.
- **Secondary (Slate Dark):** Used for high-contrast headlines and primary navigation text to ensure authority and readability.
- **Tertiary (Mint Wash):** A very light tint of the primary color, used for large background areas like card highlights or subtle button hovers.
- **Neutrals:** A sophisticated range of slates. Light grays (#F8FAFC) are used for page backgrounds to make white cards pop, while darker slates handle body text and iconography.

**Semantic Colors:**
- **Success:** Emerald #10B981
- **Warning:** Amber #F59E0B
- **Error:** Rose #F43F5E

## Typography

The system utilizes **Hanken Grotesk** as the primary typeface for its sharp, contemporary geometry and exceptional legibility in SaaS environments. **Inter** is used for smaller labels and utility text to leverage its systematic, neutral character.

- **Headlines:** Use Slate Dark (#0F172A) for maximum contrast.
- **Body:** Use Slate Medium (#475569) to maintain readability without the harshness of pure black.
- **Mobile Scaling:** Large headlines scale down on mobile viewports to prevent awkward text wrapping, ensuring titles remain readable within card headers.

## Layout & Spacing

This design system employs a **Fluid Grid** model with a 12-column structure for desktop and a single-column stack for mobile. 

- **The Card Layout:** Dashboard content is organized into white cards. Each card uses a 24px (1.5rem) internal padding. 
- **The Sidebar:** On desktop, the sidebar is fixed at 280px. On mobile, it transitions to a bottom navigation bar or a hidden drawer to maximize screen real estate for data tables.
- **Responsive Behavior:** Between 768px and 1024px (tablet), the 12-column grid collapses to 6 columns. Margin-safe areas are strictly enforced to prevent content from touching the screen edges.

## Elevation & Depth

To maintain a clean, professional look, the system avoids heavy drop shadows. Depth is created through:

1.  **Tonal Layering:** The main page background is a subtle cool gray (#F8FAFC). White containers (#FFFFFF) placed on top provide the first level of elevation.
2.  **Low-Contrast Outlines:** Instead of shadows, use a 1px border (#E2E8F0) for cards and input fields.
3.  **Soft Ambient Shadows:** For interactive elements like modals or dropdowns, use a very soft, diffused shadow: `0 10px 15px -3px rgba(0, 0, 0, 0.05)`.
4.  **Active States:** Active buttons and cards may utilize a subtle primary-colored outer glow or a slight scale increase (1.02x) rather than a deeper shadow.

## Shapes

The shape language is **Rounded**, reflecting an approachable yet professional tool.

- **Standard Elements:** Buttons, input fields, and small chips use a 0.5rem (8px) radius.
- **Containers:** Large dashboard cards and modals use the `rounded-lg` token (1rem/16px) to create a softer, more modern framing for data.
- **Selection Indicators:** Active states in the sidebar navigation use a pill-shaped indicator on one side to clearly denote the current location without cluttering the layout.

## Components

- **Buttons:** Primary buttons use a solid Teal (#14B8A6) background with white text. Secondary buttons use a Slate outline. All buttons feature a 48px height on mobile for touch accessibility.
- **Cards:** The core of the dashboard. Every card must have a 1px Slate-200 border. Use Tertiary Teal (#F0FDFA) as a header background for "Summary" or "High-Priority" cards.
- **Input Fields:** Use a 1px Slate-200 border that transitions to Teal-500 on focus. Labels are positioned above the field using the `label-md` typography token.
- **Chips/Badges:** Small, high-radius (pill) indicators for status. For example, "Active" uses a light emerald wash with dark emerald text.
- **Lists:** Data lists should use "divided" styling with a 1px horizontal line between items, avoiding boxed rows to save vertical space.
- **Tutor Cards:** Specialized components showing tutor availability and ratings, utilizing a vertical stack on mobile and a horizontal row on desktop.